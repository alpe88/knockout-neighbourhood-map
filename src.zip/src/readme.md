Neighborhood map, using KnockoutJS and Google Maps API v3
To run, download or clone repo from Github and then execute the index.html file.